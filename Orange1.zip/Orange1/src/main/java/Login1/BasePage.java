package Login1;

import org.openqa.selenium.WebDriver;

/**
 * Created by Dev on 19/11/2016.
 */
public class BasePage {

    protected static WebDriver driver;

}
